import SignIn from '@/components/Signin'
import React from 'react'

const page = () => {
  return (
    <div>
      <SignIn />
    </div>
  )
}

export default page
